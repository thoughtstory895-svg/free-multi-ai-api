import dotenv from "dotenv";
import { callHF, fallbackChat } from "../common.js";
export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "Use POST { message: string }" });
  const { message } = req.body || {};
  if (!message) return res.status(400).json({ error: "Send JSON { message: string }" });
  const ai = await callHF(`You are a helpful assistant. Answer concisely.\nUser: ${message}\nAssistant:`);
  res.json({ reply: ai || fallbackChat(message) });
}
