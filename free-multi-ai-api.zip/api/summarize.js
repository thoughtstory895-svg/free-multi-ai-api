import { callHF, fallbackSummary } from "../common.js";
export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "Use POST { text: string }" });
  const { text } = req.body || {};
  if (!text) return res.status(400).json({ error: "Send JSON { text: string }" });
  const ai = await callHF(`Summarize the following text in 2-3 sentences:\n\n${text}`);
  res.json({ summary: ai || fallbackSummary(text) });
}
