import { callHF } from "../common.js";
export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "Use POST { context, question }" });
  const { context, question } = req.body || {};
  if (!context || !question) return res.status(400).json({ error: "Send JSON { context: string, question: string }" });
  const prompt = `Answer the question using ONLY the context. If you don't know, say you don't know.\n\nContext:\n${context}\n\nQuestion: ${question}\nAnswer:`;
  const ai = await callHF(prompt);
  res.json({ answer: ai || "Sorry, I can't find the answer in the provided context." });
}
